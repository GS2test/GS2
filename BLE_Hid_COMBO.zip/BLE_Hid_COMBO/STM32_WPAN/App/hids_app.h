
/**
  ******************************************************************************
  * @file    hids_app.h
  * @author  MCD Application Team
  * @brief   Header for hids_app.c module
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2019-2021 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef HIDS_APP_H
#define HIDS_APP_H

#ifdef __cplusplus
extern "C" 
{
#endif

  /* Includes ------------------------------------------------------------------*/
  /* Exported types ------------------------------------------------------------*/

typedef struct
{
	uint8_t   reportID; /*12345*/
	uint8_t buttons;
	int8_t x;
	int8_t y;
	int8_t wheel;
} mouse_report_t;

/* Keybaord key data*/
typedef struct
{
  uint8_t ReportID;
  uint8_t Data_0;
  uint8_t Data_1;
  uint8_t Data_2;
  uint8_t Data_3;
  uint8_t Data_4;
  uint8_t Data_5;
  uint8_t Data_6;
  uint8_t Data_7;
} keyboard_report_t;

/* Multimedia key data*/
typedef struct
{
  uint8_t ReportID;
  uint8_t Data_0;
  uint8_t Data_1;
  uint8_t Data_2;
  uint8_t Data_3;
} multimedia_report_t;

#define MOUSE_REPORT_SIZE	80

#define MOUSE_REPORT_ID		0x01
#define KEYBOARD_REPORT_ID	0x02
#define MEDIA_REPORT_ID		0x03

static uint8_t report_mouse[MOUSE_REPORT_SIZE] =
{
	0x05, 0x01,         	/* USAGE_PAGE (Generic Desktop) */

	0x09, 0x02,         	/* USAGE (Mouse) */
	0xa1, 0x01,         	/* COLLECTION (Application) */
	0x85, MOUSE_REPORT_ID,	/*      Report ID (1) */
	0x09, 0x01,         	/*   USAGE (Pointer) */
	0xa1, 0x00,         	/*   COLLECTION (Physical) */
	0x05, 0x09,         	/*     USAGE_PAGE (Button) */
	0x19, 0x01,         	/*     USAGE_MINIMUM (Button 1) */
	0x29, 0x03,         	/*     USAGE_MAXIMUM (Button 3) */
	0x15, 0x00,         	/*     LOGICAL_MINIMUM (0) */
	0x25, 0x01,         	/*     LOGICAL_MAXIMUM (1) */
	0x95, 0x03,         	/*     REPORT_COUNT (3) */
	0x75, 0x01,         	/*     REPORT_SIZE (1) */
	0x81, 0x02,         	/*     INPUT (Data,Var,Abs) */

	0x95, 0x01,         	/*     REPORT_COUNT (1) */
	0x75, 0x05,         	/*     REPORT_SIZE (5) */
	0x81, 0x03,         	/*     INPUT (Cnst,Var,Abs) */

	0x05, 0x01,         	/*     USAGE_PAGE (Generic Desktop) */
	0x09, 0x30,         	/*     USAGE (X) */
	0x09, 0x31,         	/*     USAGE (Y) */
	0x09, 0x38,         	/*     USAGE (Wheel) */
	0x15, 0x81,         	/*     LOGICAL_MINIMUM (-127) */
	0x25, 0x7f,         	/*     LOGICAL_MAXIMUM (127) */
	0x75, 0x08,         	/*     REPORT_SIZE (8) */
	0x95, 0x03,         	/*     REPORT_COUNT (3) */
	0x81, 0x06,         	/*     INPUT (Data,Var,Rel) */
	0xc0,               	/*   END_COLLECTION (Physical) */
	0xc0,               	/* END_COLLECTION (Application) */


	0x09, 0x06,         		/* USAGE (Keyboard) */
	0xa1, 0x01,         		/* COLLECTION (Application) */
	0x85, KEYBOARD_REPORT_ID,	/*     REPORT ID (0x02) */
	0x05, 0x07,         		/*   USAGE_PAGE (Keyboard) */
	0xa1, 0x01,         		/*   COLLECTION (Application) */
	0x95, 0x08,         		/*     REPORT_COUNT (8) */
	0x75, 0x08,            		/*     REPORT_SIZE (8) */
	0x15, 0x00,  				/*     LOGICAL_MINIMUM (0) */
	0x25, 0xff,    				/*     LOGICAL_MAXIMUM (255) */
	0x19, 0x00,    				/*     USAGE_MINIMUM (0) */
	0x29, 0xff,   				/*     USAGE_MAXIMUM (255) */
	0x81, 0x00,     			/*     INPUT (Data,Var,Abs) */
	0xc0,           			/*   END_COLLECTION (Application) */
	0xc0               			/* END_COLLECTION (Application) */
};

typedef enum
{
  KEY_A         = 0x04,
  KEY_B, KEY_C, KEY_D, KEY_E, KEY_F, KEY_G, KEY_H, KEY_I, KEY_J, KEY_K,
  KEY_L, KEY_M, KEY_N, KEY_O, KEY_P, KEY_Q, KEY_R, KEY_S, KEY_T, KEY_U,
  KEY_V, KEY_W, KEY_X, KEY_Y, KEY_Z,

  KEY_1         = 0x1E,
  KEY_2         = 0x1F,
  KEY_3         = 0x20,
  KEY_4         = 0x21,
  KEY_5         = 0x22,
  KEY_6, KEY_7, KEY_8, KEY_9, KEY_0,
} T_KEYBOARD_KEYCODE;

  /* Exported constants --------------------------------------------------------*/
  /* External variables --------------------------------------------------------*/
  /* Exported macros -----------------------------------------------------------*/
  /* Exported functions ------------------------------------------------------- */
  void HIDSAPP_Init(void);
//void HIDSAPP_Profile_UpdateChar(void);
  void HIDSAPP_Keyboard_UpdateChar(void);
  void HIDSAPP_Mouse_UpdateChar(void);

#ifdef __cplusplus
}
#endif

#endif /* HIDS_APP_H */
