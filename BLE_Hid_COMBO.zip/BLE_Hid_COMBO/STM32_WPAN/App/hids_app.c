/**
  ******************************************************************************
  * @file    hids_app.c
  * @author  MCD Application Team
  * @brief   Human Interface Device Service Application
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2019-2021 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */



/* Includes ------------------------------------------------------------------*/
#include "app_common.h"

#include "dbg_trace.h"
#include "app_ble.h"
#include "ble.h"
#include "hids_app.h"
#include "stm32_seq.h"
#include <time.h>
#include "hids_menu.h"


/* Private typedef -----------------------------------------------------------*/
#if((BLE_CFG_HIDS_INPUT_REPORT_NB != 0) || (BLE_CFG_HIDS_KEYBOARD_DEVICE != 0) || (BLE_CFG_HIDS_MOUSE_DEVICE != 0))
typedef struct
{
#if(BLE_CFG_HIDS_INPUT_REPORT_NB != 0)
  uint8_t ReportNotificationEnabled[BLE_CFG_HIDS_INPUT_REPORT_NB];
#endif
#if(BLE_CFG_HIDS_KEYBOARD_DEVICE != 0)
  uint8_t KeyboardInputNotificationEnabled;
#endif
#if(BLE_CFG_HIDS_MOUSE_DEVICE != 0)
  uint8_t MouseInputNotificationEnabled;
#endif
} HIDSAPP_Context_t;
#endif

/* Private defines -----------------------------------------------------------*/


#define ENABLED         1
#define DISABLED        0

  
/* Private macros ------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/


/**
 * START of Section BLE_APP_CONTEXT
 */

#if((BLE_CFG_HIDS_INPUT_REPORT_NB != 0) || (BLE_CFG_HIDS_KEYBOARD_DEVICE != 0) || (BLE_CFG_HIDS_MOUSE_DEVICE != 0))
HIDSAPP_Context_t HIDSAPP_Context[BLE_CFG_HIDS_NUMBER];
#endif

/**
 * END of Section BLE_APP_CONTEXT
 */

/* Global variables ----------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Functions Definition ------------------------------------------------------*/
/* Private functions ----------------------------------------------------------*/
/* Public functions ----------------------------------------------------------*/
void HIDS_Notification(HIDS_App_Notification_evt_t *pNotification)
{
  switch(pNotification->HIDS_Evt_Opcode)
  {

#if(BLE_CFG_HIDS_INPUT_REPORT_NB != 0)
    case HIDS_REPORT_NOTIFICATION_ENABLED:
      {
        BLE_DBG_APP_MSG("HIDS_REPORT_NOTIFICATION_ENABLED\n");
        HIDSAPP_Context[pNotification->Index].ReportNotificationEnabled[pNotification->Index] = ENABLED;
      }
      break;

    case HIDS_REPORT_NOTIFICATION_DISABLED:
      {
        BLE_DBG_APP_MSG("HIDS_REPORT_NOTIFICATION_DISABLED\n");
        HIDSAPP_Context[pNotification->Index].ReportNotificationEnabled[pNotification->Index] = DISABLED;
      }
      break;
#endif
      
#if(BLE_CFG_HIDS_KEYBOARD_DEVICE != 0)
    case HIDS_KEYB_INPUT_NOTIFY_ENABLED:
      {
        BLE_DBG_APP_MSG("HIDS_KEYB_INPUT_NOTIFY_ENABLED\n");
        HIDSAPP_Context[pNotification->Index].KeyboardInputNotificationEnabled = ENABLED;
      }
      break;

    case HIDS_KEYB_INPUT_NOTIFY_DISABLED:
      {
        BLE_DBG_APP_MSG("HIDS_KEYB_INPUT_NOTIFY_DISABLED\n");
        HIDSAPP_Context[pNotification->Index].KeyboardInputNotificationEnabled = DISABLED;
      }
      break;
#endif

#if(BLE_CFG_HIDS_MOUSE_DEVICE != 0)          
    case HIDS_MOUSE_INPUT_NOTIFY_ENABLED:
      {
        BLE_DBG_APP_MSG("HIDS_MOUSE_INPUT_NOTIFY_ENABLED\n");
        HIDSAPP_Context[pNotification->Index].MouseInputNotificationEnabled = ENABLED;
      }
      break;

    case HIDS_MOUSE_INPUT_NOTIFY_DISABLED:
      {
        BLE_DBG_APP_MSG("HIDS_MOUSE_INPUT_NOTIFY_DISABLED\n");
        HIDSAPP_Context[pNotification->Index].MouseInputNotificationEnabled = DISABLED;
      }
      break;
#endif

#if(BLE_CFG_HIDS_OUTPUT_REPORT_NB != 0)
    case HIDS_OUTPUT_REPORT:
      {
        uint8_t i;
        
        BLE_DBG_APP_MSG("HIDS_OUTPUT_REPORT\n");
        BLE_DBG_HIDS_MSG("HID Instance %d Report %d \n", 
                          pNotification->Instance,
                          pNotification->Index); 
    
        for(i = 0; i < pNotification->ReportLength; i++)
          BLE_DBG_HIDS_MSG("Report[%d] 0x%X \n",
                           i,
                           pNotification->pReport[i]);
      }
      break;
#endif
    
#if((BLE_CFG_HIDS_MOUSE_DEVICE != 0) && (BLE_CFG_HIDS_MOUSE_INPUT_WRITE != 0))
    case HIDS_MOUSE_INPUT_REPORT:
      {
        uint8_t i;
        
        BLE_DBG_APP_MSG("HIDS_MOUSE_INPUT_REPORT\n");
        BLE_DBG_HIDS_MSG("HID Instance %d Report %d \n", 
                          pNotification->Instance,
                          pNotification->Index); 
    
        for(i = 0; i < pNotification->ReportLength; i++)
          BLE_DBG_HIDS_MSG("Report[%d] 0x%X \n",
                           i,
                           pNotification->pReport[i]);
      }
      break;
#endif
      
#if((BLE_CFG_HIDS_KEYBOARD_DEVICE != 0) && (BLE_CFG_HIDS_KEYBOARD_INPUT_WRITE != 0))
    case HIDS_KEYBOARD_INPUT_REPORT:
      {
        uint8_t i;
        
        BLE_DBG_APP_MSG("HIDS_KEYBOARD_INPUT_REPORT\n");
        BLE_DBG_HIDS_MSG("HID Instance %d Report %d \n", 
                          pNotification->Instance,
                          pNotification->Index); 
    
        for(i = 0; i < pNotification->ReportLength; i++)
          BLE_DBG_HIDS_MSG("Report[%d] 0x%X \n",
                           i,
                           pNotification->pReport[i]);
      }
      break;

    case HIDS_KEYBOARD_OUTPUT_REPORT:
      {
        uint8_t i;
        
        BLE_DBG_APP_MSG("HIDS_KEYBOARD_OUTPUT_REPORT\n");
        BLE_DBG_HIDS_MSG("HID Instance %d Report %d \n", 
                          pNotification->Instance,
                          pNotification->Index); 
    
        for(i = 0; i < pNotification->ReportLength; i++)
          BLE_DBG_HIDS_MSG("Report[%d] 0x%X \n",
                           i,
                           pNotification->pReport[i]);
      }
      break;
#endif
      
    default:
      break;
  }

  return;
}


void HIDSAPP_Init(void)
{
  tBleStatus result = BLE_STATUS_INVALID_PARAMS;

  UTIL_SEQ_RegTask( 1<< CFG_TASK_HID_KEYBOARD_REQ_ID, UTIL_SEQ_RFU, HIDSAPP_Keyboard_UpdateChar );
  UTIL_SEQ_RegTask( 1<< CFG_TASK_HID_MOUSE_REQ_ID, UTIL_SEQ_RFU, HIDSAPP_Mouse_UpdateChar );


  result = HIDS_Update_Char(REPORT_MAP_CHAR_UUID, 
                            0, 
                            0, 
                            MOUSE_REPORT_SIZE,
                            (uint8_t *)&report_mouse);

  if( result == BLE_STATUS_SUCCESS )
  {
    BLE_DBG_APP_MSG("Report Map Successfully Sent\n");
  }
  else 
  {
    BLE_DBG_APP_MSG("Sending of Report Map Failed error 0x%X\n", result);
  }
}


/**
 * @brief  Alert Notification Application service update characteristic
 * @param  None
 * @retval None
 */

mouse_report_t mouse_report;

void HIDSAPP_Mouse_UpdateChar(void)
{
    tBleStatus result = BLE_STATUS_INVALID_PARAMS;

    result = HIDS_Update_Char(REPORT_CHAR_UUID, 
                              0, 
                              0, 
                              sizeof(mouse_report_t),
                              (uint8_t *)& mouse_report);

    if( result == BLE_STATUS_SUCCESS )
    {
      BLE_DBG_APP_MSG("Mouse Report 0x%x %d %d %d Successfully Sent\n",
                       mouse_report.buttons,
                       mouse_report.x,
                       mouse_report.y,
                       mouse_report.wheel);
    }
    else 
    {
      BLE_DBG_APP_MSG("Sending of Mouse Report Failed error 0x%X\n", result);
    }
}

T_KEYBOARD_KEYCODE KeyCode0;

void  HIDSAPP_Keyboard_UpdateChar(void)
{
  tBleStatus result = BLE_STATUS_INVALID_PARAMS;

  keyboard_report_t keyboard_keydata = {0x00, };

  BLE_DBG_APP_MSG("++Process_GenericKeyboard_Demo\n");

  //For press key
  keyboard_keydata.ReportID = KEYBOARD_REPORT_ID;
  keyboard_keydata.Data_2 = KeyCode0;
  result = HIDS_Update_Char(REPORT_CHAR_UUID,
                            0,
                            0,
                            sizeof(keyboard_report_t),
                            (uint8_t *)& keyboard_keydata);

  if( result == BLE_STATUS_SUCCESS )
  {
    BLE_DBG_APP_MSG("Keyboard Report(P) (Report ID : 0x%02X), %02X %02X %02X %02X %02X %02X %02X %02X Successfully Sent\n",
      keyboard_keydata.ReportID, keyboard_keydata.Data_0, keyboard_keydata.Data_1, keyboard_keydata.Data_2, keyboard_keydata.Data_3,
      keyboard_keydata.Data_4, keyboard_keydata.Data_5, keyboard_keydata.Data_6, keyboard_keydata.Data_7);
  }
  else
  {
    BLE_DBG_APP_MSG("Sending of Keyboard Report(P) Failed error 0x%X\n", result);
  }

  //For release key
  keyboard_keydata.Data_2 = 0x00;
  result = HIDS_Update_Char(REPORT_CHAR_UUID,
                            0,
                            0,
                            sizeof(keyboard_report_t),
                            (uint8_t *)& keyboard_keydata);

  if( result == BLE_STATUS_SUCCESS )
  {
    BLE_DBG_APP_MSG("Keyboard Report(P) (Report ID : 0x%02X), %02X %02X %02X %02X %02X %02X %02X %02X Successfully Sent\n",
      keyboard_keydata.ReportID, keyboard_keydata.Data_0, keyboard_keydata.Data_1, keyboard_keydata.Data_2, keyboard_keydata.Data_3,
      keyboard_keydata.Data_4, keyboard_keydata.Data_5, keyboard_keydata.Data_6, keyboard_keydata.Data_7);
  }
  else
  {
    BLE_DBG_APP_MSG("Sending of Keyboard Report(R) Failed error 0x%X\n", result);
  }
}

