/**
  @page BLE_Hid application
  
  @verbatim
  ******************************************************************************
  * @file    BLE/BLE_Hid/readme.txt 
  * @author  MCD Application Team
  * @brief   Description of the BLE Human Interface Device application.
  ******************************************************************************
  *
  * Copyright (c) 2019-2021 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  @endverbatim

@par application Description

How to use the Human Interface Device profile as specified by the BLE SIG.

@note Care must be taken when using HAL_Delay(), this function provides accurate delay (in milliseconds)
      based on variable incremented in SysTick ISR. This implies that if HAL_Delay() is called from
      a peripheral ISR process, then the SysTick interrupt must have higher priority (numerically lower)
      than the peripheral interrupt. Otherwise the caller ISR process will be blocked.
      To change the SysTick interrupt priority you have to use HAL_NVIC_SetPriority() function.
      
@note The application needs to ensure that the SysTick time base is always set to 1 millisecond
      to have correct HAL operation.

@par Keywords

Connectivity, BLE, IPCC, HSEM, RTC, UART, PWR, BLE protocol, BLE pairing, BLE profile, Dual core

@par Directory contents 
  
  - BLE/BLE_Hid/Core/Inc/app_common.h                Header for all modules with common definition
  - BLE/BLE_Hid/Core/Inc/app_conf.h                  Application configuration file for STM32WPAN Middleware
  - BLE/BLE_Hid/Core/Inc/app_debug.h                 Header for app_debug.c module
  - BLE/BLE_Hid/Core/Inc/app_entry.h                 Interface to the application
  - BLE/BLE_Hid/Core/Inc/hw_conf.h                   Configuration file of the HW
  - BLE/BLE_Hid/Core/Inc/hw_if.h                     Hardware Interface
  - BLE/BLE_Hid/Core/Inc/main.h                      Header for main.c module
  - BLE/BLE_Hid/Core/Inc/stm32wbxx_hal_conf.h        HAL configuration file
  - BLE/BLE_Hid/Core/Inc/stm32wbxx_it.h              Interrupt handlers header file
  - BLE/BLE_Hid/Core/Inc/stm32_lpm_if.h              Header for stm32_lpm_if.c module (device specific LP management)
  - BLE/BLE_Hid/Core/Inc/utilities_conf.h            Configuration file of the utilities
  - BLE/BLE_Hid/STM32_WPAN/App/app_ble.h             Header for app_ble.c module
  - BLE/BLE_Hid/STM32_WPAN/App/bas_app.h             Header for bats_app.c module
  - BLE/BLE_Hid/STM32_WPAN/App/ble_conf.h            BLE Services configuration
  - BLE/BLE_Hid/STM32_WPAN/App/ble_dbg_conf.h        BLE Traces configuration of the BLE services
  - BLE/BLE_Hid/STM32_WPAN/App/dis_app.h             Header for dis_app.c module
  - BLE/BLE_Hid/STM32_WPAN/App/hids_app.h            Header for hids_app.c module
  - BLE/BLE_Hid/STM32_WPAN/App/tl_dbg_conf.h         Debug configuration file for stm32wpan transport layer interface
  - BLE/BLE_Hid/Core/Src/app_debug.c                 Debug capabilities source file for STM32WPAN Middleware
  - BLE/BLE_Hid/Core/Src/app_entry.c                 Initialization of the application
  - BLE/BLE_Hid/Core/Src/hw_timerserver.c            Timer Server based on RTC
  - BLE/BLE_Hid/Core/Src/hw_uart.c                   UART Driver
  - BLE/BLE_Hid/Core/Src/main.c                      Main program
  - BLE/BLE_Hid/Core/Src/stm32wbxx_hal_msp.c         This file provides code for the MSP Initialization and de-Initialization
  - BLE/BLE_Hid/Core/Src/stm32wbxx_it.c              Interrupt handlers
  - BLE/BLE_Hid/Core/Src/stm32_lpm_if.c              Low Power Manager Interface
  - BLE/BLE_Hid/Core/Src/system_stm32wbxx.c          stm32wbxx system source file
  - BLE/BLE_Hid/STM32_WPAN/App/app_ble.c             BLE Profile implementation
  - BLE/BLE_Hid/STM32_WPAN/App/bas_app.c             Battery Service Application
  - BLE/BLE_Hid/STM32_WPAN/App/dis_app.c             Device Information Service application
  - BLE/BLE_Hid/STM32_WPAN/App/hids_app.c            Human Interface Device Service Application
  - BLE/BLE_Hid/STM32_WPAN/Target/hw_ipcc.c          IPCC Driver
     
@par Hardware and Software environment

  - This application runs on STM32WB55xx devices.
  
  - This application has been tested with an STMicroelectronics P-NUCLEO-WB55
    board and can be easily tailored to any other supported device 
    and development board.
    
@par PC should have Bluetooth Adapter
    
@note This BLE_HID example have been modefied by using STM32CubeIDI v1.16.0 
into BLE_HID_COMBO example to use MOUSE and KEYBOARD as one HID device. 

@par How to use it ? 

Step 1. This application requires having the stm32wb5x_BLE_Stack_full_fw.bin binary flashed on the Wireless Coprocessor.
	You need to use STM32CubeProgrammer v2.16.0 to load the follow binary.
	
	1.1. Connect the board to PC using USB cable.
	1.2. Click "Connect" on Programmer(see Board: NUCLEO-WB55RG)
	1.3. Click "Firmware Upgrade Services" menu button
	1.4. Browse to \STM32Cube\Repository\STM32Cube_FW_WB_V1.20.0\Projects\
		STM32WB_Copro_Wireless_Binaries\STM32WB5x\stm32wb5x_FUS_fw.bin file
	1.5. Enter "Start address" 0x080EC000
	1.6. Click "Start FUS" button in "WB Command" Programmer panel
	1.7. Click "Start Wireless stack" button
	1.8. Click "Read FUS infos": "FUS Version": v1.2.0.0
	1.9. Browse to \STM32Cube\Repository\STM32Cube_FW_WB_V1.20.0\Projects\
		STM32WB_Copro_Wireless_Binaries\STM32WB5x\stm32wb5x_BLE_Stack_full_fw.bin
	1.10. Enter "Start address"  0x080C E000
	1.11. Click "Firmware Upgrade" button
	
All available binaries are located under /Projects/STM32_Copro_Wireless_Binaries directory.
Refer to /Projects/STM32_Copro_Wireless_Binaries/ReleaseNote.html for the detailed procedure to change the
Wireless Coprocessor binary or see following wiki for Hardware setup:
https://wiki.st.com/stm32mcu/wiki/Connectivity:STM32WB_BLE_Hardware_Setup

Step 2. In order to make the program work, you must do the following:
	2.1. Rebuild project files by using STM32CubeIDI v1.16.0 
	2.2. Click "Erasing $ Programming" menu button
	2.3. Browse to the executable file: BLE_Hid_COMBO\STM32CubeIDE\Debug\BLE_Hid_COMBO.elf
	2.4. Click "Start programming" button to Flash the board with the executable file - 
		BLE_Hid_COMBO\STM32CubeIDE\Debug\BLE_Hid_COMBO.elf
	2.5. Click "Disconnect" on Programmer

Step 3. To Run the application you need:
	3.1. To unplug the board from USB
	3.2. Plug it to the same or another usb or
		connect the board to another power supply.
 
Step 4. To prepair PC/Smartphone:
	4.1. Enable the Bluetooth communication (PC: or install any Bluetooth 4.0 USB adapter dongle)
		LMP 6 and higher on Device manager/Bluetooth Adapter/Properties/Advanced/Firmware
	4.2. Click "Add Device" On Settings/Bluetooth & Devices/Add a device/ blurtooth
	4.3. Click "Combo" on the list
	4.4. Enter pin code "222222" [from app_conf.h] into field "Enter the pin for Combo"
	4.5. Click "Connect"
	4.6. See "COMBO" connected and click "Done" button
		[If you need to remove it later - click ... more option on "COMBO".connected on this page 
		and "Remove device"]

Step 5. On the Nucleo board side:
	5.1. Open Notepad and click SW1 - number 3 should be printed
	5.2. Click SW2 - cursor on the screen should move to the right and down and page scroll down.
	5.3. Click SW3 - cursor on the screen should move to the left and up
	5.4. Open Notepad and click switch[SW4] connected to PC6[D2] and Ground - number 4 should be printed
	5.5. Open Notepad and click switch[SW5] connected to PC10[D4] and Ground - number 5 should be printed

Available Wiki pages:
  - https://wiki.st.com/stm32mcu/wiki/Connectivity:BLE_overview

 